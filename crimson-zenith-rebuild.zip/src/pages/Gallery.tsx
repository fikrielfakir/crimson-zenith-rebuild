import { useState, useRef, useEffect, useCallback, useMemo, lazy, Suspense } from "react";
import { useTranslation } from "react-i18next";
import { motion, useMotionValue, useSpring, AnimatePresence } from "framer-motion";
import {
  MapPin, X, ChevronLeft, ChevronRight, Upload, Search,
  Home, ChevronRight as CRight, Heart, Share2, Download,
  Move, MousePointer, MousePointer2, Maximize2, Minimize2,
} from "lucide-react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import MetaverseBackground from "@/components/MetaverseBackground";

const PanoramaOverlay = lazy(() => import("@/components/PanoramaOverlay"));

/* ─── types ──────────────────────────────────────────────────────────── */
interface TourStop { yaw: number; pitch: number; label: string; targetId: number; }
interface GalleryItem {
  id: number; type: string; url: string; title: string;
  location?: string; photographer?: string; tags?: string[];
  category?: string; likes?: number; description?: string;
  aspect?: "portrait" | "landscape";
  panoramaUrl?: string;
  has360?: boolean;
  hotspots?: TourStop[];
}

/* ─── static data ────────────────────────────────────────────────────── */
const STATIC_GALLERY: GalleryItem[] = [
  { id:1, type:"photo", aspect:"portrait",
    url:"https://images.unsplash.com/photo-1539020140153-e479b8c22e70?w=800&q=90",
    title:"High Atlas Mountains", location:"Imlil, Morocco",
    photographer:"Sarah M.", tags:["mountain","landscape"], category:"mountain", likes:128,
    description:"Breathtaking peaks rising above the clouds over the High Atlas range.",
    has360: true,
    panoramaUrl: "https://photo-sphere-viewer-data.netlify.app/assets/sphere.jpg",
    hotspots: [
      { yaw: 0.80, pitch: 0,    label: "Sahara Desert",  targetId: 2 },
      { yaw: -1.05, pitch: -0.14, label: "Todra Gorge", targetId: 7 },
    ] },
  { id:2, type:"photo", aspect:"landscape",
    url:"https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=800&q=90",
    title:"Sahara Desert", location:"Merzouga, Morocco",
    photographer:"Ahmed K.", tags:["desert","sahara"], category:"desert", likes:95,
    description:"Golden hour illuminating the endless dunes of the Sahara.",
    has360: true,
    panoramaUrl: "https://photo-sphere-viewer-data.netlify.app/assets/sphere-small.jpg",
    hotspots: [
      { yaw: 0.52, pitch: 0.09, label: "High Atlas Mountains", targetId: 1 },
      { yaw: -0.78, pitch: -0.09, label: "Todra Gorge",        targetId: 7 },
    ] },
  { id:3, type:"photo", aspect:"portrait",
    url:"https://images.unsplash.com/photo-1548696056-01a4a7b4e9e7?w=800&q=90",
    title:"Blue Streets", location:"Chefchaouen, Morocco",
    photographer:"Layla S.", tags:["city","blue"], category:"cultural", likes:210,
    description:"The iconic blue-washed alleyways of Morocco's mountain city." },
  { id:4, type:"photo", aspect:"landscape",
    url:"https://images.unsplash.com/photo-1553603229-5b0e7b6a3b3e?w=800&q=90",
    title:"Aït Ben Haddou", location:"Ouarzazate, Morocco",
    photographer:"Omar L.", tags:["ksar","history"], category:"cultural", likes:74,
    description:"Ancient fortified village glowing at the edge of the desert." },
  { id:5, type:"photo", aspect:"landscape",
    url:"https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=800&q=90",
    title:"Desert Sunset", location:"Erg Chebbi, Morocco",
    photographer:"Youssef A.", tags:["desert","sunset"], category:"desert", likes:61,
    description:"A camel caravan silhouetted against the burning horizon." },
  { id:6, type:"photo", aspect:"portrait",
    url:"https://images.unsplash.com/photo-1585016495481-91613a0a5c8f?w=800&q=90",
    title:"Local Culture", location:"Marrakech, Morocco",
    photographer:"Fatima R.", tags:["culture","people"], category:"cultural", likes:43,
    description:"Vibrant colours and traditions alive in the ancient medina." },
  { id:7, type:"photo", aspect:"landscape",
    url:"https://images.unsplash.com/photo-1500463959177-e0869687b1f7?w=800&q=90",
    title:"Todra Gorge", location:"Tinghir, Morocco",
    photographer:"Hassan M.", tags:["gorge","adventure"], category:"adventure", likes:88,
    description:"Towering limestone walls carving through the heart of the Atlas.",
    has360: true,
    panoramaUrl: "https://photo-sphere-viewer-data.netlify.app/assets/sphere.jpg",
    hotspots: [
      { yaw: 1.05, pitch: 0,    label: "High Atlas Mountains", targetId: 1 },
      { yaw: -0.60, pitch: -0.08, label: "Sahara Desert",      targetId: 2 },
    ] },
  { id:8, type:"photo", aspect:"portrait",
    url:"https://images.unsplash.com/photo-1552665945-afd7c01898f9?w=800&q=90",
    title:"Fes Medina", location:"Fès, Morocco",
    photographer:"Nadia H.", tags:["architecture","medina"], category:"cultural", likes:56,
    description:"Labyrinthine streets of the world's largest living medieval city." },
];

/* ─── slot positions (pixels) ────────────────────────────────────────── */
const SLOTS = [
  { tx:    0, ty:    0, tz:   80, ry:   0, rx:  0, blur:false, zi:20 }, // center
  { tx: -420, ty: -160, tz: -120, ry:  18, rx: -3, blur:false, zi:13 }, // top-left
  { tx: -480, ty:   80, tz: -200, ry:  22, rx:  4, blur:false, zi:12 }, // bot-left
  { tx:  380, ty: -180, tz: -150, ry: -20, rx: -3, blur:false, zi:13 }, // top-right
  { tx:  420, ty:  100, tz: -100, ry: -15, rx:  4, blur:false, zi:12 }, // bot-right
  { tx: -640, ty:    0, tz: -300, ry:  44, rx:  0, blur:true,  zi: 2 }, // far-left
  { tx:  640, ty:   40, tz: -300, ry: -44, rx:  0, blur:true,  zi: 2 }, // far-right
];
const SCENE_H = 700;
const PERSP   = 1200;

const CATEGORY_IDS = ["all", "mountain", "desert", "cultural", "adventure"];

function cardDims(isCenter: boolean, isBlur: boolean, aspect?: "portrait"|"landscape") {
  const w = isCenter ? 300 : isBlur ? 168 : 238;
  const h = isCenter
    ? (aspect === "landscape" ? 265 : 385)
    : isBlur
      ? (aspect === "landscape" ? 195 : 245)
      : (aspect === "landscape" ? 222 : 308);
  return { w, h };
}

/* ─── CSS keyframes injected once ───────────────────────────────────── */
const GLOBAL_CSS = `
  @keyframes twinkle    { 0%,100%{opacity:.18} 50%{opacity:.85} }
  @keyframes twinkBright{ 0%,100%{opacity:.4;filter:blur(.5px)} 50%{opacity:1;filter:blur(0)} }
  @keyframes dashScroll { to { stroke-dashoffset:-24 } }
  @keyframes pulseRing  { 0%,100%{opacity:.06} 50%{opacity:.14} }
  @keyframes auroraShift{ 0%{opacity:0;transform:translateX(-12%) skewX(-8deg)} 35%{opacity:1} 65%{opacity:.7} 100%{opacity:0;transform:translateX(16%) skewX(-8deg)} }
  @keyframes gridPulse  { 0%,100%{opacity:.045} 50%{opacity:.09} }
  @keyframes centerPulse{ 0%,100%{opacity:.12;transform:translate(-50%,-50%) scale(1)} 50%{opacity:.26;transform:translate(-50%,-50%) scale(1.06)} }
  @keyframes badge360Ring { 0%{box-shadow:0 0 0 0 rgba(30,144,255,0.65)} 100%{box-shadow:0 0 0 10px rgba(30,144,255,0)} }
`;

/* ─── 360° badge ─────────────────────────────────────────────────────── */
function Badge360({ small = false }: { small?: boolean }) {
  return (
    <div style={{
      display: "inline-flex", alignItems: "center",
      background: "linear-gradient(135deg, #1E90FF, #00C8FF)",
      borderRadius: 999,
      fontSize: small ? 9 : 11, fontWeight: 700,
      color: "#fff", padding: small ? "2px 6px" : "3px 8px",
      letterSpacing: "0.06em",
      animation: "badge360Ring 1.6s ease-out infinite",
      boxShadow: "0 0 0 0 rgba(30,144,255,0.65)",
      whiteSpace: "nowrap",
      userSelect: "none",
    }}>
      360°
    </div>
  );
}

/* ─── stable random seeds ────────────────────────────────────────────── */
function seededRand(seed: number) {
  const x = Math.sin(seed + 1) * 10000;
  return x - Math.floor(x);
}

/* ─── star field ─────────────────────────────────────────────────────── */
function StarField() {
  const stars = useMemo(() => Array.from({ length:240 }, (_, i) => ({
    id: i,
    x: seededRand(i * 3.1) * 100,
    y: seededRand(i * 7.7) * 100,
    size: seededRand(i * 2.3) < 0.60 ? seededRand(i * 5.1) * 1.2 + 0.25 : seededRand(i * 9.9) * 3.2 + 1,
    bright: seededRand(i * 4.4) > 0.82,
    twinkle: seededRand(i * 6.6) > 0.40,
    color: seededRand(i * 11.3) > 0.88 ? "#e0c8ff" : seededRand(i * 11.3) > 0.76 ? "#c8e8ff" : "#d6eeff",
    dur: seededRand(i * 8.2) * 5 + 2.5,
    delay: seededRand(i * 1.9) * 9,
  })), []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" style={{ zIndex:1 }}>
      {stars.map(s => (
        <div key={s.id} style={{
          position:"absolute", left:`${s.x}%`, top:`${s.y}%`,
          width:s.size, height:s.size, borderRadius:"50%",
          background: s.bright
            ? `radial-gradient(circle, ${s.color} 0%, rgba(120,195,255,0.55) 60%, transparent 100%)`
            : "rgba(190,218,255,0.58)",
          boxShadow: s.bright ? `0 0 ${s.size*4}px rgba(160,210,255,0.6)` : "none",
          animation: s.twinkle
            ? `${s.bright ? "twinkBright" : "twinkle"} ${s.dur}s ${s.delay}s infinite ease-in-out`
            : "none",
        }} />
      ))}
    </div>
  );
}

/* ─── nebula drift blobs ─────────────────────────────────────────────── */
function NebulaBlobs() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" style={{ zIndex:2 }}>
      {[
        { left:"-10%", top:"10%",  w:"58%", h:"70%", bg:"radial-gradient(circle, rgba(29,78,216,0.13) 0%, rgba(0,40,140,0.06) 45%, transparent 70%)",   ax:[-22,18,-22], ay:[-10,14,-10], dur:32 },
        { left:"52%",  top:"15%",  w:"55%", h:"65%", bg:"radial-gradient(circle, rgba(0,100,220,0.11) 0%, rgba(0,40,180,0.05) 50%, transparent 70%)",     ax:[18,-12,18],  ay:[12,-18,12],  dur:38 },
        { left:"20%",  top:"-22%", w:"60%", h:"70%", bg:"radial-gradient(circle, rgba(96,140,255,0.09) 0%, transparent 70%)",                              ax:[0,0,0],      ay:[0,0,0],      dur:28, scl:[1,1.10,1] },
        { left:"-5%",  top:"55%",  w:"40%", h:"50%", bg:"radial-gradient(circle, rgba(120,60,220,0.07) 0%, rgba(80,20,180,0.03) 50%, transparent 70%)",   ax:[10,-8,10],   ay:[-6,10,-6],   dur:42 },
        { left:"65%",  top:"50%",  w:"45%", h:"55%", bg:"radial-gradient(circle, rgba(0,180,220,0.06) 0%, rgba(0,100,200,0.03) 50%, transparent 70%)",    ax:[-14,10,-14], ay:[8,-12,8],    dur:36 },
        { left:"30%",  top:"30%",  w:"42%", h:"42%", bg:"radial-gradient(circle, rgba(60,100,255,0.05) 0%, transparent 65%)",                              ax:[5,-5,5],     ay:[-4,6,-4],    dur:24, scl:[1,1.06,1] },
      ].map((b, i) => (
        <motion.div key={i}
          style={{
            position:"absolute", left:b.left, top:b.top, width:b.w, height:b.h,
            background:b.bg, filter:"blur(40px)",
          }}
          animate={{ x:b.ax, y:b.ay, scale:(b as any).scl ?? [1,1,1] }}
          transition={{ duration:b.dur, repeat:Infinity, ease:"easeInOut" }}
        />
      ))}
    </div>
  );
}

/* ─── aurora light ribbons ───────────────────────────────────────────── */
function AuroraEffect() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" style={{ zIndex:3 }}>
      {[
        { top:"8%",  left:"5%",  w:"55%", h:"18%", bg:"linear-gradient(90deg, transparent 0%, rgba(59,130,246,0.10) 30%, rgba(99,102,241,0.14) 55%, rgba(139,92,246,0.08) 75%, transparent 100%)", dur:14, delay:0 },
        { top:"18%", left:"35%", w:"50%", h:"14%", bg:"linear-gradient(90deg, transparent 0%, rgba(0,200,255,0.07) 25%, rgba(59,130,246,0.11) 55%, rgba(99,102,241,0.07) 80%, transparent 100%)", dur:18, delay:5 },
        { top:"72%", left:"-5%", w:"60%", h:"16%", bg:"linear-gradient(90deg, transparent 0%, rgba(120,60,220,0.08) 30%, rgba(59,130,246,0.10) 60%, transparent 100%)", dur:22, delay:9 },
      ].map((a, i) => (
        <div key={i} style={{
          position:"absolute", top:a.top, left:a.left, width:a.w, height:a.h,
          background:a.bg, filter:"blur(22px)", borderRadius:"50%",
          animation:`auroraShift ${a.dur}s ${a.delay}s infinite ease-in-out`,
        }}/>
      ))}
    </div>
  );
}

/* ─── cosmic perspective grid ────────────────────────────────────────── */
function CosmicGrid() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" style={{ zIndex:2 }}>
      <div style={{
        position:"absolute", bottom:"-10%", left:"-20%", right:"-20%", height:"55%",
        backgroundImage:[
          "linear-gradient(to right, rgba(37,99,235,0.08) 1px, transparent 1px)",
          "linear-gradient(to bottom, rgba(37,99,235,0.08) 1px, transparent 1px)",
        ].join(", "),
        backgroundSize:"80px 60px",
        transform:"perspective(600px) rotateX(68deg)",
        transformOrigin:"bottom center",
        maskImage:"radial-gradient(ellipse 80% 60% at 50% 100%, rgba(0,0,0,0.55) 0%, transparent 80%)",
        WebkitMaskImage:"radial-gradient(ellipse 80% 60% at 50% 100%, rgba(0,0,0,0.55) 0%, transparent 80%)",
        animation:"gridPulse 6s infinite ease-in-out",
      }}/>
    </div>
  );
}

/* ─── ambient particles ──────────────────────────────────────────────── */
const DUST = Array.from({ length:60 }, (_, i) => ({
  id:i, x:seededRand(i*3.3)*100, y:seededRand(i*5.5)*100,
  size: seededRand(i*7.7)*2.6+0.5,
  delay:seededRand(i*2.1)*5, dur:seededRand(i*4.4)*3.5+2.5,
  op:seededRand(i*6.6)*0.4+0.08,
}));

function AmbientDust() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" style={{ zIndex:3 }}>
      {DUST.map(d => (
        <motion.div key={d.id} className="absolute rounded-full"
          style={{
            left:`${d.x}%`, top:`${d.y}%`, width:d.size, height:d.size,
            background: d.size > 2
              ? "radial-gradient(circle, rgba(100,170,255,0.8), rgba(37,99,235,0.4))"
              : "rgba(170,210,255,0.7)",
          }}
          animate={{ opacity:[d.op, d.op*2.8, d.op], y:[0,-16,0] }}
          transition={{ duration:d.dur, delay:d.delay, repeat:Infinity, ease:"easeInOut" }}
        />
      ))}
    </div>
  );
}

/* ─── SVG: orbital rings + connecting lines ──────────────────────────── */
function OrbitalSVG({ sceneW, slotAssignments }: {
  sceneW: number;
  slotAssignments: Array<{ slot: typeof SLOTS[0]; slotIdx: number }>;
}) {
  const cx = sceneW / 2;
  const cy = SCENE_H / 2;

  const endpoints = slotAssignments
    .filter(a => a.slotIdx > 0)
    .map(({ slot }) => {
      const f = PERSP / (PERSP - slot.tz);
      return {
        x: cx + slot.tx * f * 0.55,
        y: cy + slot.ty * f * 0.55,
        blur: slot.blur,
      };
    });

  return (
    <svg
      className="absolute inset-0 pointer-events-none"
      width={sceneW} height={SCENE_H}
      style={{ zIndex:16, overflow:"visible" }}
    >
      <defs>
        <filter id="svg-glow" x="-80%" y="-80%" width="260%" height="260%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="3" result="blur"/>
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
        <filter id="line-glow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="1.5" result="blur"/>
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
        <radialGradient id="centerHalo" cx="50%" cy="50%" r="50%">
          <stop offset="0%"   stopColor="rgba(37,99,235,0.22)"/>
          <stop offset="100%" stopColor="rgba(37,99,235,0)"/>
        </radialGradient>
      </defs>

      {/* center halo pulse */}
      <ellipse cx={cx} cy={cy} rx={80} ry={48}
        fill="url(#centerHalo)" style={{ animation:"pulseRing 4s infinite ease-in-out" }}/>

      {/* orbital rings */}
      <ellipse cx={cx} cy={cy} rx={sceneW*0.36} ry={SCENE_H*0.195}
        fill="none" stroke="rgba(37,99,235,0.07)" strokeWidth="1"
        strokeDasharray="6 14"
        style={{ animation:"dashScroll 18s linear infinite" }}/>
      <ellipse cx={cx} cy={cy} rx={sceneW*0.495} ry={SCENE_H*0.265}
        fill="none" stroke="rgba(0,120,255,0.042)" strokeWidth="1"
        strokeDasharray="4 18"
        style={{ animation:"dashScroll 26s linear infinite reverse" }}/>
      <ellipse cx={cx} cy={cy} rx={sceneW*0.25} ry={SCENE_H*0.135}
        fill="none" stroke="rgba(100,180,255,0.06)" strokeWidth="0.5"/>

      {/* connecting lines from center to each card */}
      {endpoints.map((ep, i) => (
        <g key={i} filter="url(#line-glow)">
          <line
            x1={cx} y1={cy} x2={ep.x} y2={ep.y}
            stroke={ep.blur ? "rgba(37,99,235,0.06)" : "rgba(60,150,255,0.18)"}
            strokeWidth={ep.blur ? 0.5 : 0.8}
            strokeDasharray="3 9"
            style={{ animation:`dashScroll ${12+i*3}s linear infinite` }}
          />
          <circle cx={ep.x} cy={ep.y} r={ep.blur ? 2 : 3.5}
            fill={ep.blur ? "rgba(60,150,255,0.15)" : "rgba(100,180,255,0.35)"}
            filter="url(#svg-glow)"/>
        </g>
      ))}

      {/* center node */}
      <circle cx={cx} cy={cy} r={5} fill="rgba(100,190,255,0.45)" filter="url(#svg-glow)"/>
      <circle cx={cx} cy={cy} r={12} fill="none" stroke="rgba(100,190,255,0.18)" strokeWidth="1"/>
    </svg>
  );
}

/* ─── volumetric center bloom ────────────────────────────────────────── */
function VolumetricBloom() {
  return (
    <div className="absolute inset-0 pointer-events-none" style={{ zIndex:4 }}>
      {/* outer atmospheric haze */}
      <div style={{
        position:"absolute", left:"50%", top:"50%",
        transform:"translate(-50%,-50%)",
        width:"90%", height:"100%",
        background:"radial-gradient(ellipse, rgba(29,78,216,0.08) 0%, rgba(10,25,80,0.04) 50%, transparent 72%)",
        filter:"blur(30px)",
      }}/>
      {/* wide bloom ring */}
      <div style={{
        position:"absolute", left:"50%", top:"50%",
        transform:"translate(-50%,-50%)",
        width:"65%", height:"75%",
        background:"radial-gradient(ellipse, rgba(37,99,235,0.14) 0%, rgba(15,40,120,0.06) 45%, transparent 70%)",
        filter:"blur(22px)",
      }}/>
      {/* tight center glow — animated pulse */}
      <div style={{
        position:"absolute", left:"50%", top:"50%",
        width:"32%", height:"40%",
        background:"radial-gradient(ellipse, rgba(59,130,246,0.26) 0%, rgba(37,99,235,0.10) 55%, transparent 100%)",
        filter:"blur(14px)",
        animation:"centerPulse 5s infinite ease-in-out",
      }}/>
      {/* inner hot spot */}
      <div style={{
        position:"absolute", left:"50%", top:"50%",
        transform:"translate(-50%,-50%)",
        width:"14%", height:"18%",
        background:"radial-gradient(ellipse, rgba(147,197,253,0.22) 0%, rgba(59,130,246,0.12) 60%, transparent 100%)",
        filter:"blur(8px)",
      }}/>
    </div>
  );
}

/* ─── edge vignette / fog ────────────────────────────────────────────── */
function FogVignette() {
  return (
    <div className="absolute inset-0 pointer-events-none" style={{ zIndex:30 }}>
      {/* left / right fog */}
      <div style={{
        position:"absolute", inset:0,
        background:"radial-gradient(ellipse 100% 100% at 50% 50%, transparent 38%, rgba(4,13,33,0.55) 75%, rgba(4,13,33,0.85) 100%)",
      }}/>
      {/* bottom fade-in to page bg */}
      <div style={{
        position:"absolute", bottom:0, left:0, right:0, height:120,
        background:"linear-gradient(to top, #040d21 0%, transparent 100%)",
      }}/>
      {/* top fade */}
      <div style={{
        position:"absolute", top:0, left:0, right:0, height:80,
        background:"linear-gradient(to bottom, #040d21 0%, transparent 100%)",
      }}/>
    </div>
  );
}

/* ─── ground ring ────────────────────────────────────────────────────── */
function GroundRing() {
  return (
    <div className="absolute pointer-events-none" style={{
      bottom: "8%", left: "50%",
      transform: "translateX(-50%)",
      zIndex: 5,
    }}>
      {[380, 260, 160].map((size, i) => (
        <div key={i} style={{
          position: "absolute",
          width: size * 2,
          height: size * 0.55,
          border: "1px solid rgba(50,150,255,0.20)",
          borderRadius: "50%",
          top: "50%", left: "50%",
          transform: `translate(-50%,-50%) rotateX(75deg)`,
          animation: `pulseRing ${4 + i * 1.5}s ${i * 0.8}s infinite ease-in-out`,
        }}/>
      ))}
    </div>
  );
}

/* ─── premium glass card ─────────────────────────────────────────────── */
interface CardProps {
  item: GalleryItem; slot: typeof SLOTS[0];
  sceneW: number; isCenter: boolean; isFlying: boolean;
  onClick: () => void;
}

function GlassCard({ item, slot, isCenter, isFlying, onClick }: CardProps) {
  const { t } = useTranslation();
  const [hovered, setHovered] = useState(false);
  const { w, h } = cardDims(isCenter, slot.blur, item.aspect);

  const px = slot.tx;
  const py = slot.ty;

  /* ── layered bloom shadow ── */
  const shadow = isCenter
    ? [
        "inset 0 1px 0 rgba(255,255,255,0.13)",
        "inset 0 -1px 0 rgba(37,99,235,0.22)",
        "0 0 0 1px rgba(110,195,255,0.22)",
        "0 0 25px rgba(37,99,235,0.60)",
        "0 0 65px rgba(37,99,235,0.28)",
        "0 0 130px rgba(37,99,235,0.14)",
        "0 0 220px rgba(37,99,235,0.06)",
        "0 45px 110px rgba(0,0,0,0.80)",
      ].join(", ")
    : hovered
      ? [
          "inset 0 1px 0 rgba(255,255,255,0.1)",
          "0 0 0 1px rgba(110,195,255,0.28)",
          "0 0 22px rgba(37,99,235,0.52)",
          "0 0 55px rgba(37,99,235,0.24)",
          "0 0 100px rgba(37,99,235,0.10)",
          "0 25px 70px rgba(0,0,0,0.70)",
        ].join(", ")
      : slot.blur
        ? "0 0 10px rgba(37,99,235,0.10), 0 10px 30px rgba(0,0,0,0.50)"
        : [
            "inset 0 1px 0 rgba(255,255,255,0.07)",
            "0 0 0 1px rgba(80,140,255,0.14)",
            "0 0 14px rgba(37,99,235,0.18)",
            "0 12px 40px rgba(0,0,0,0.58)",
          ].join(", ");

  const borderCol = isCenter
    ? "rgba(120,200,255,0.40)"
    : hovered ? "rgba(120,200,255,0.48)" : "rgba(80,140,255,0.16)";

  return (
    <motion.div
      className="absolute cursor-pointer"
      style={{
        left:"50%", top:"50%", marginLeft:-w/2, marginTop:-h/2,
        zIndex:slot.zi, transformStyle:"preserve-3d",
      }}
      animate={{
        x:px, y:py, z:slot.tz,
        rotateY:slot.ry, rotateX:slot.rx, scale:slot.scale,
        opacity: slot.blur ? 0.55 : 1,
        filter: slot.blur ? "blur(3px) brightness(0.6)" : "blur(0px) brightness(1)",
      }}
      transition={{
        type:"spring",
        stiffness: isFlying ? 155 : 195,
        damping:   isFlying ? 19  : 25,
        mass:      isFlying ? 1.4 : 1,
        opacity:  { duration:0.4 },
        filter:   { duration:0.5 },
      }}
      whileHover={!slot.blur ? {
        scale: slot.scale * (isCenter ? 1.04 : 1.08),
        z: slot.tz + 60,
        transition:{ duration:0.32, ease:"easeOut" },
      } : undefined}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      onClick={onClick}
    >
      {/* idle float */}
      <motion.div
        style={{ width:w, height:h }}
        animate={{ y: isCenter ? [0,-10,0] : slot.tx < 0 ? [0,-6,3,0] : [0,4,-6,0] }}
        transition={{
          duration: isCenter ? 4.0 : 4.5 + Math.abs(slot.tx)*0.03,
          repeat:Infinity, ease:"easeInOut",
          delay: Math.abs(slot.tx)*0.028,
        }}
      >
        {/* ── card shell ── */}
        <div style={{
          position:"relative", width:w, height:h, borderRadius:18, overflow:"visible",
          boxShadow: shadow,
          border:`1px solid ${borderCol}`,
          transition:"box-shadow 0.4s ease, border-color 0.4s ease",
        }}>
          {/* inner clip */}
          <div style={{ position:"absolute", inset:0, borderRadius:17, overflow:"hidden" }}>

            {/* image */}
            <img src={item.url} alt={item.title} style={{
              position:"absolute", inset:0, width:"100%", height:"100%",
              objectFit:"cover",
              transform: hovered ? "scale(1.08)" : "scale(1)",
              transition:"transform 0.6s ease",
              filter:"brightness(0.82) saturate(1.18) contrast(1.06)",
            }}
            onError={e => {
              (e.target as HTMLImageElement).src =
                `https://placehold.co/${w}x${h}/0a1f5c/4a9eff?text=${encodeURIComponent(item.title)}`;
            }}
            />

            {/* dark glass base */}
            <div style={{
              position:"absolute", inset:0,
              background:"rgba(6,15,45,0.20)",
            }}/>

            {/* diagonal reflection sheen */}
            <div style={{
              position:"absolute", inset:0,
              background:"linear-gradient(135deg, rgba(255,255,255,0.11) 0%, rgba(255,255,255,0.03) 30%, transparent 55%)",
            }}/>

            {/* top rim light */}
            <div style={{
              position:"absolute", top:0, left:0, right:0, height:isCenter ? 60 : 40,
              background:"linear-gradient(to bottom, rgba(120,200,255,0.13) 0%, transparent 100%)",
            }}/>

            {/* bottom rim glow */}
            <div style={{
              position:"absolute", bottom:0, left:0, right:0, height:isCenter ? 70 : 50,
              background:"linear-gradient(to top, rgba(37,99,235,0.22) 0%, transparent 100%)",
            }}/>

            {/* scan lines holographic */}
            <div style={{
              position:"absolute", inset:0,
              background:"repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(100,170,255,0.014) 3px, rgba(100,170,255,0.014) 4px)",
              mixBlendMode:"overlay",
            }}/>

            {/* hover inner bloom */}
            {hovered && (
              <motion.div
                initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}
                style={{
                  position:"absolute", inset:0,
                  background:"radial-gradient(ellipse at 50% 0%, rgba(59,130,246,0.28) 0%, transparent 65%)",
                }}
              />
            )}

            {/* caption */}
            <div style={{
              position:"absolute", bottom:0, left:0, right:0,
              padding: isCenter ? "14px 16px" : "9px 11px",
              background:"linear-gradient(to top, rgba(4,12,40,0.95) 0%, rgba(4,12,40,0.60) 60%, transparent 100%)",
              backdropFilter:"blur(6px)",
            }}>
              <p style={{
                fontWeight:700, color:"#f0f8ff", lineHeight:1.2,
                fontSize: isCenter ? 15 : slot.blur ? 10 : 12,
                textShadow:"0 1px 8px rgba(0,0,0,0.8)",
              }}>{item.title}</p>
              {item.location && (
                <div style={{ display:"flex", alignItems:"center", gap:4, marginTop:4 }}>
                  <MapPin style={{ width:isCenter?11:9, height:isCenter?11:9, color:"#7dd3fc", flexShrink:0 }}/>
                  <span style={{ fontSize:isCenter?10:8.5, color:"rgba(125,211,252,0.80)", letterSpacing:"0.02em" }}>
                    {item.location}
                  </span>
                </div>
              )}
            </div>

            {/* FEATURED badge */}
            {isCenter && (
              <motion.div
                animate={{ opacity:[0.85,1,0.85] }}
                transition={{ duration:2.5, repeat:Infinity }}
                style={{
                  position:"absolute", top:12, right:12,
                  background:"rgba(29,78,216,0.75)",
                  backdropFilter:"blur(10px)",
                  borderRadius:20, padding:"4px 11px",
                  border:"1px solid rgba(120,195,255,0.40)",
                  fontSize:9, fontWeight:700, color:"#dbeafe",
                  letterSpacing:"0.08em",
                  boxShadow:"0 0 12px rgba(37,99,235,0.45)",
                }}>
                {t("gallery.badgeFeatured")}
              </motion.div>
            )}

            {/* 360° badge — top-left, shown on all 360-capable cards */}
            {item.has360 && (
              <div style={{
                position:"absolute", top:12, left:12,
                zIndex:4,
              }}>
                <Badge360 small={!isCenter}/>
              </div>
            )}

            {/* center 360° click hint */}
            {isCenter && item.has360 && (
              <motion.div
                initial={{ opacity:0, y:4 }} animate={{ opacity:1, y:0 }}
                transition={{ delay:0.5 }}
                style={{
                  position:"absolute", bottom:isCenter ? 68 : 54, left:"50%",
                  transform:"translateX(-50%)",
                  background:"rgba(14,40,120,0.85)", backdropFilter:"blur(12px)",
                  borderRadius:20, padding:"4px 12px",
                  border:"1px solid rgba(30,144,255,0.50)",
                  fontSize:9, fontWeight:700, color:"#bfdbfe",
                  letterSpacing:"0.08em", whiteSpace:"nowrap",
                  boxShadow:"0 0 16px rgba(30,144,255,0.45)",
                  pointerEvents:"none",
                }}>
                {t("gallery.badge360Enter")}
              </motion.div>
            )}

            {/* hover ring pulse on side cards */}
            {!isCenter && !slot.blur && hovered && (
              <motion.div
                style={{ position:"absolute", inset:0, borderRadius:17, pointerEvents:"none" }}
                animate={{ boxShadow:[
                  "inset 0 0 0 1.5px rgba(120,200,255,0.0)",
                  "inset 0 0 0 1.5px rgba(120,200,255,0.65)",
                  "inset 0 0 0 1.5px rgba(120,200,255,0.0)",
                ]}}
                transition={{ duration:1.2, repeat:Infinity }}
              />
            )}

            {/* click-to-feature label */}
            {!isCenter && !slot.blur && hovered && (
              <motion.div
                initial={{ opacity:0, y:4 }} animate={{ opacity:1, y:0 }}
                style={{
                  position:"absolute", top:10, left:"50%", transform:"translateX(-50%)",
                  background:"rgba(37,99,235,0.82)", backdropFilter:"blur(10px)",
                  borderRadius:20, padding:"3px 10px",
                  border:"1px solid rgba(120,195,255,0.40)",
                  fontSize:9, fontWeight:700, color:"#dbeafe",
                  letterSpacing:"0.08em", whiteSpace:"nowrap",
                  boxShadow:"0 0 14px rgba(37,99,235,0.50)",
                  pointerEvents:"none",
                }}>
                {t("gallery.badgeSetFeatured")}
              </motion.div>
            )}
          </div>

          {/* floor reflection — center card only */}
          {isCenter && (
            <div style={{
              position:"absolute", top:"100%", left:4, right:4, height:h*0.38,
              overflow:"hidden", borderRadius:"0 0 12px 12px", pointerEvents:"none",
            }}>
              <img src={item.url} alt="" style={{
                width:"100%", height:"100%", objectFit:"cover",
                transform:"scaleY(-1)",
                filter:"blur(4px) brightness(0.35) saturate(0.7)",
                maskImage:"linear-gradient(to bottom, rgba(0,0,0,0.45) 0%, transparent 100%)",
                WebkitMaskImage:"linear-gradient(to bottom, rgba(0,0,0,0.45) 0%, transparent 100%)",
              }}
              onError={e => { (e.target as HTMLImageElement).style.display="none"; }}
              />
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─── fullscreen modal ───────────────────────────────────────────────── */
function FullscreenModal({ item, onClose, onPrev, onNext }: {
  item: GalleryItem|null; onClose:()=>void; onPrev:()=>void; onNext:()=>void;
}) {
  useEffect(() => {
    const h = (e:KeyboardEvent) => {
      if (e.key==="Escape") onClose();
      if (e.key==="ArrowLeft") onPrev();
      if (e.key==="ArrowRight") onNext();
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose, onPrev, onNext]);

  return (
    <AnimatePresence>
      {item && (
        <motion.div className="fixed inset-0 z-[100] flex items-center justify-center"
          initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}
          transition={{ duration:0.38 }} onClick={onClose}
        >
          {/* blurred backdrop */}
          <div className="absolute inset-0"
            style={{ background:"rgba(2,7,22,0.94)", backdropFilter:"blur(24px)" }}/>

          {/* floating particles */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {Array.from({length:22},(_,i) => (
              <motion.div key={i} className="absolute rounded-full"
                style={{
                  left:`${seededRand(i*3.3)*100}%`,
                  top:`${seededRand(i*7.7)*100}%`,
                  width:seededRand(i*5.5)*3+1,
                  height:seededRand(i*5.5)*3+1,
                  background:"rgba(120,200,255,0.35)",
                }}
                animate={{ opacity:[0.12,0.65,0.12], y:[0,-22,0] }}
                transition={{ duration:seededRand(i*2.2)*3+2.5, repeat:Infinity, delay:seededRand(i*4.4)*3 }}
              />
            ))}
          </div>

          <motion.div
            className="relative z-10 flex items-center gap-5 px-4 max-w-4xl w-full"
            style={{ direction: "ltr" }}
            initial={{ scale:0.80, y:40, opacity:0 }}
            animate={{ scale:1, y:0, opacity:1 }}
            exit={{ scale:0.88, y:22, opacity:0 }}
            transition={{ duration:0.52, ease:[0.16,1,0.3,1] }}
            onClick={e => e.stopPropagation()}
          >
            {[{icon:ChevronLeft, fn:onPrev},{icon:ChevronRight, fn:onNext}].map(({ icon:Icon, fn }, side) => (
              <button key={side} onClick={fn}
                className="shrink-0 w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110"
                style={{
                  background:"rgba(12,36,90,0.70)", backdropFilter:"blur(12px)",
                  border:"1px solid rgba(120,195,255,0.28)",
                  boxShadow:"0 0 20px rgba(37,99,235,0.20)",
                  order: side === 1 ? 3 : 1,
                }}>
                <Icon className="w-5 h-5 text-white"/>
              </button>
            ))}

            <div className="flex-1 rounded-2xl overflow-hidden" style={{
              order:2,
              background:"rgba(5,15,50,0.75)",
              border:"1px solid rgba(120,195,255,0.22)",
              boxShadow:"0 0 90px rgba(37,99,235,0.30), 0 50px 110px rgba(0,0,0,0.75)",
              backdropFilter:"blur(20px)",
            }}>
              <div className="relative" style={{ maxHeight:"58vh" }}>
                <img src={item.url} alt={item.title}
                  className="w-full object-cover" style={{ maxHeight:"58vh",
                    filter:"brightness(0.92) saturate(1.1)" }}
                  onError={e => { (e.target as HTMLImageElement).src =
                    `https://placehold.co/800x540/0a1f5c/4a9eff?text=${encodeURIComponent(item.title)}`; }}
                />
                {/* scan line overlay */}
                <div style={{
                  position:"absolute", inset:0, pointerEvents:"none",
                  background:"repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(100,170,255,0.01) 3px, rgba(100,170,255,0.01) 4px)",
                }}/>
                <button onClick={onClose}
                  className="absolute top-3 right-3 w-9 h-9 rounded-full flex items-center justify-center transition-all hover:scale-110"
                  style={{
                    background:"rgba(5,15,50,0.85)",
                    border:"1px solid rgba(120,195,255,0.30)",
                    boxShadow:"0 0 14px rgba(37,99,235,0.30)",
                  }}>
                  <X className="w-4 h-4 text-white"/>
                </button>
              </div>

              <div className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold text-white mb-1.5"
                      style={{ textShadow:"0 0 20px rgba(59,130,246,0.4)" }}>
                      {item.title}
                    </h2>
                    {item.location && (
                      <div className="flex items-center gap-1.5 text-sky-300 text-sm mb-2">
                        <MapPin className="w-3.5 h-3.5"/>{item.location}
                      </div>
                    )}
                    {item.description && (
                      <p className="text-white/55 text-sm leading-relaxed">{item.description}</p>
                    )}
                  </div>
                  <div className="flex gap-2 shrink-0">
                    {[Heart, Share2, Download].map((Icon, i) => (
                      <button key={i}
                        className="w-8 h-8 rounded-full flex items-center justify-center transition-all hover:scale-110"
                        style={{
                          border:"1px solid rgba(120,195,255,0.20)",
                          background:"rgba(29,78,216,0.18)",
                        }}>
                        <Icon className="w-4 h-4 text-sky-300"/>
                      </button>
                    ))}
                  </div>
                </div>
                {item.tags && item.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {item.tags.map(t => (
                      <span key={t} className="text-xs px-2.5 py-0.5 rounded-full text-sky-200/75"
                        style={{ background:"rgba(37,99,235,0.16)", border:"1px solid rgba(37,99,235,0.28)" }}>
                        #{t}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ─── main gallery page ──────────────────────────────────────────────── */
export default function Gallery() {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';
  const CATEGORIES = CATEGORY_IDS.map(id => ({
    id,
    label: t(`gallery.categories.${id}`),
  }));
  const [category,     setCategory]     = useState("all");
  const [search,       setSearch]       = useState("");
  const [selected,     setSelected]     = useState<GalleryItem|null>(null);
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>(STATIC_GALLERY);
  const [scrollY,      setScrollY]      = useState(0);
  const [centerIdx,    setCenterIdx]    = useState(0);
  const [flyingFrom,   setFlyingFrom]   = useState<number|null>(null);
  const [sceneW,       setSceneW]       = useState(1200);
  const [mouseIdle,      setMouseIdle]      = useState(true);
  const [panoramaItem,   setPanoramaItem]   = useState<GalleryItem|null>(null);
  const [overlayOpacity, setOverlayOpacity] = useState(0.72);
  const [isFullscreen,   setIsFullscreen]   = useState(false);

  useEffect(() => {
    const onFSChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFSChange);
    return () => document.removeEventListener("fullscreenchange", onFSChange);
  }, []);

  const toggleFullscreen = useCallback(() => {
    const el = document.getElementById("gallery-scene-section");
    if (!el) return;
    if (!document.fullscreenElement) {
      el.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  }, []);

  /* Z-axis dolly from scroll wheel */
  const sceneZ  = useMotionValue(0);
  const sSceneZ = useSpring(sceneZ, { stiffness:60, damping:18 });

  const sceneRef    = useRef<HTMLDivElement>(null);
  const isDragging  = useRef(false);
  const lastMouse   = useRef({ x:0, y:0 });
  const idleTimer   = useRef<ReturnType<typeof setTimeout>|null>(null);

  /* spring scene rotation */
  const rotX  = useMotionValue(0);
  const rotY  = useMotionValue(0);
  const sRotX = useSpring(rotX, { stiffness:50, damping:16 });
  const sRotY = useSpring(rotY, { stiffness:50, damping:16 });

  /* idle drift — slow sinusoidal oscillation when no mouse activity */
  useEffect(() => {
    if (!mouseIdle) return;
    let raf: number;
    let t = 0;
    const drift = () => {
      t += 0.006;
      rotY.set(Math.sin(t) * 7);
      rotX.set(Math.cos(t * 0.65) * 3.5);
      raf = requestAnimationFrame(drift);
    };
    raf = requestAnimationFrame(drift);
    return () => cancelAnimationFrame(raf);
  }, [mouseIdle, rotX, rotY]);

  /* measure scene width */
  useEffect(() => {
    const upd = () => setSceneW(sceneRef.current?.clientWidth ?? 1200);
    upd();
    window.addEventListener("resize", upd);
    return () => window.removeEventListener("resize", upd);
  }, []);

  /* fetch real gallery items from admin-managed gallery API */
  useEffect(() => {
    fetch("/api/gallery")
      .then(r => r.ok ? r.json() : null)
      .then((data: unknown) => {
        if (!data) return;
        const raw  = data as Record<string, unknown>;
        const items = (Array.isArray(raw["items"]) ? raw["items"] : []) as Record<string, unknown>[];
        if (items.length >= 1) {
          setGalleryItems(items.map((it, i) => ({
            id:           Number(it["id"]) || i,
            type:         "photo",
            url:          String(it["image_url"] ?? STATIC_GALLERY[i % STATIC_GALLERY.length].url),
            title:        String(it["title"]       || STATIC_GALLERY[i % STATIC_GALLERY.length].title),
            location:     it["location"]   ? String(it["location"])   : STATIC_GALLERY[i % STATIC_GALLERY.length].location,
            photographer: it["photographer"]? String(it["photographer"]): STATIC_GALLERY[i % STATIC_GALLERY.length].photographer,
            tags:         STATIC_GALLERY[i % STATIC_GALLERY.length].tags,
            category:     it["category"]   ? String(it["category"])   : STATIC_GALLERY[i % STATIC_GALLERY.length].category,
            likes:        STATIC_GALLERY[i % STATIC_GALLERY.length].likes,
            description:  it["description"]? String(it["description"]): STATIC_GALLERY[i % STATIC_GALLERY.length].description,
            aspect:       (it["aspect"] === "portrait" ? "portrait" : "landscape") as "portrait" | "landscape",
            has360:       Boolean(it["has_360"]),
            panoramaUrl:  it["panorama_url"] ? String(it["panorama_url"]) : undefined,
            hotspots:     it["hotspots"] ? (it["hotspots"] as TourStop[]) : undefined,
          })));
        }
      }).catch(() => {});
  }, []);

  useEffect(() => {
    const h = () => {
      const y = window.scrollY;
      setScrollY(y);
      const gallerySection = document.getElementById("gallery-scene-section");
      if (gallerySection) {
        const bottom = gallerySection.getBoundingClientRect().bottom;
        const progress = Math.max(0, Math.min(1, 1 - bottom / window.innerHeight));
        setOverlayOpacity(0.72 + progress * 0.20);
      }
    };
    window.addEventListener("scroll", h, { passive:true });
    return () => window.removeEventListener("scroll", h);
  }, []);

  /* wheel handler — only dolly when hovering the scene */
  const onWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const next = Math.max(-200, Math.min(200, sceneZ.get() - e.deltaY * 0.4));
    sceneZ.set(next);
  }, [sceneZ]);

  /* filtered list */
  const filtered = galleryItems.filter(it => {
    const mc = category === "all" || it.category === category;
    const ms = !search ||
      it.title.toLowerCase().includes(search.toLowerCase()) ||
      (it.location?.toLowerCase().includes(search.toLowerCase()) ?? false);
    return mc && ms;
  });

  useEffect(() => { setCenterIdx(0); }, [category, search]);

  /* mouse / drag scene interaction */
  const onMouseMove = useCallback((e: React.MouseEvent) => {
    /* reset idle timer */
    setMouseIdle(false);
    if (idleTimer.current) clearTimeout(idleTimer.current);
    idleTimer.current = setTimeout(() => setMouseIdle(true), 3500);

    if (!sceneRef.current) return;
    if (!isDragging.current) {
      const r = sceneRef.current.getBoundingClientRect();
      rotY.set(((e.clientX - r.left - r.width/2)  / r.width)  * 15);
      rotX.set(-((e.clientY - r.top  - r.height/2) / r.height) * 8);
      return;
    }
    rotY.set(rotY.get() + (e.clientX - lastMouse.current.x) * 0.21);
    rotX.set(rotX.get() - (e.clientY - lastMouse.current.y) * 0.13);
    lastMouse.current = { x:e.clientX, y:e.clientY };
  }, [rotX, rotY]);

  const onMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    lastMouse.current = { x:e.clientX, y:e.clientY };
  };
  const onMouseUp    = () => { isDragging.current = false; };
  const onMouseLeave = () => {
    isDragging.current = false;
    setMouseIdle(true);
  };

  /* carousel click */
  function handleCardClick(slotIdx: number) {
    if (slotIdx === 0) {
      const item = filtered[centerIdx];
      if (item.panoramaUrl) {
        // 300ms delay so the card scale-up animation plays first
        setTimeout(() => setPanoramaItem(item), 300);
      } else {
        setSelected(item);
      }
    } else {
      setFlyingFrom(slotIdx);
      setCenterIdx((centerIdx + slotIdx) % filtered.length);
      setTimeout(() => setFlyingFrom(null), 950);
    }
  }

  function goNext() {
    setFlyingFrom(1);
    setCenterIdx((centerIdx + 1) % filtered.length);
    setTimeout(() => setFlyingFrom(null), 950);
  }
  function goPrev() {
    setFlyingFrom(filtered.length - 1);
    setCenterIdx((centerIdx - 1 + filtered.length) % filtered.length);
    setTimeout(() => setFlyingFrom(null), 950);
  }

  /* item-to-slot mapping (item.id is React key — persists across re-renders) */
  const n = Math.min(SLOTS.length, filtered.length);
  const slotAssignments = Array.from({ length:n }, (_, i) => ({
    slot:    SLOTS[i],
    item:    filtered[(centerIdx + i) % filtered.length],
    slotIdx: i,
  }));

  /* modal nav */
  const closeItem = () => setSelected(null);
  const prevItem  = () => {
    if (!selected) return;
    const idx = filtered.findIndex(x => x.id === selected.id);
    setSelected(filtered[(idx - 1 + filtered.length) % filtered.length]);
  };
  const nextItem  = () => {
    if (!selected) return;
    const idx = filtered.findIndex(x => x.id === selected.id);
    setSelected(filtered[(idx + 1) % filtered.length]);
  };

  return (
    <div className="min-h-screen" style={{ background:"transparent", position:"relative" }}>
      {/* inject CSS keyframes */}
      <style>{GLOBAL_CSS}</style>

      {/* ── z-index 0: 360° metaverse background sphere ───────────── */}
      <MetaverseBackground paused={!!panoramaItem} />

      {/* ── z-index 1: radial dark overlay (scroll-responsive) ────── */}
      <div style={{
        position:"fixed", inset:0, zIndex:1, pointerEvents:"none",
        background:`radial-gradient(ellipse at center, rgba(2,11,30,0.45) 0%, rgba(2,11,30,${overlayOpacity}) 60%, rgba(2,11,30,0.88) 100%)`,
        transition:"background 0.3s ease",
      }}/>

      {/* ── z-index 2: particle field already inside scene section ── */}

      {/* ── z-index 10+: all page content ───────────────────────── */}
      <div style={{ position:"relative", zIndex:10 }}>

      <Header/>

      {/* ── HERO ─────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden pt-40 pb-12 md:pt-60 md:pb-14">
        <div className="absolute inset-0"
          style={{ background:"linear-gradient(180deg, rgba(4,13,33,0.18) 0%, rgba(4,13,33,0.72) 100%)" }}/>
        <div className="relative container mx-auto px-6">
          <nav className="mb-8">
            <ol className="flex items-center gap-2 text-sm">
              <li>
                <Link to="/" className="flex items-center gap-1.5 text-white/75 hover:text-white transition-colors px-3 py-1.5 rounded-full backdrop-blur-sm"
                  style={{ background:"rgba(255,255,255,0.07)", border:"1px solid rgba(255,255,255,0.12)" }}>
                  <Home className="w-3.5 h-3.5"/> {t("gallery.home")}
                </Link>
              </li>
              <CRight className="w-4 h-4 text-white/35"/>
              <li>
                <span className="text-white font-semibold px-3 py-1.5 rounded-full"
                  style={{ background:"rgba(255,255,255,0.10)", border:"1px solid rgba(255,255,255,0.20)" }}>
                  {t("gallery.title")}
                </span>
              </li>
            </ol>
          </nav>
          <motion.h1
            className="text-3xl md:text-5xl lg:text-7xl font-bold text-white mb-3 md:mb-4"
            style={{ textShadow:"0 0 70px rgba(59,130,246,0.42)" }}
            initial={{ opacity:0, y:24 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.75 }}>
            {t("gallery.title")}
          </motion.h1>
          <motion.p className="text-lg text-white/68 max-w-xl leading-relaxed"
            initial={{ opacity:0, y:24 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.75, delay:0.15 }}>
            {t("gallery.heroSubtitle")}
          </motion.p>
        </div>
      </section>

      {/* ── FILTERS ──────────────────────────────────────────────── */}
      <section className="py-7" style={{ background:"rgba(4,13,33,0.97)", borderBottom:"1px solid rgba(37,99,235,0.10)" }}>
        <div className="container mx-auto px-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-sky-400/50"/>
              <input type="text" value={search} onChange={e => setSearch(e.target.value)}
                placeholder={t("gallery.searchPlaceholder")}
                className="pl-10 pr-4 py-2.5 rounded-full text-sm text-white/90 placeholder-white/25 outline-none w-60"
                style={{
                  background:"rgba(10,30,80,0.55)",
                  border:"1px solid rgba(100,160,255,0.18)",
                  backdropFilter:"blur(14px)",
                }}
              />
            </div>
            <div className="flex gap-2 flex-wrap justify-center">
              {CATEGORIES.map(cat => (
                <button key={cat.id} onClick={() => setCategory(cat.id)}
                  className="px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-300"
                  style={{
                    background: category === cat.id
                      ? "linear-gradient(135deg,#1d4ed8,#2563eb)"
                      : "rgba(10,30,80,0.45)",
                    border: category === cat.id
                      ? "1px solid rgba(120,195,255,0.50)"
                      : "1px solid rgba(100,160,255,0.13)",
                    color: category === cat.id ? "#fff" : "rgba(120,195,255,0.68)",
                    boxShadow: category === cat.id
                      ? "0 0 22px rgba(37,99,235,0.35), 0 0 6px rgba(37,99,235,0.5)"
                      : "none",
                    backdropFilter:"blur(10px)",
                  }}>
                  {cat.label}
                </button>
              ))}
            </div>
            <span className="text-sm" style={{ color:"rgba(120,195,255,0.42)" }}>{t("gallery.photoCount", { count: filtered.length })}</span>
          </div>
        </div>
      </section>

      {/* ── MOBILE GRID (< 640 px) ───────────────────────────────── */}
      {sceneW > 0 && sceneW < 640 && (
        <section className="py-6 px-4" style={{ background:"rgba(4,13,33,0.97)" }}>
          <div className="grid grid-cols-2 gap-3">
            {filtered.map((item) => (
              <div key={item.id}
                className="relative overflow-hidden rounded-xl cursor-pointer group"
                style={{ aspectRatio: item.aspect === "portrait" ? "3/4" : "4/3" }}
                onClick={() => setSelected(item)}
              >
                <img src={item.url} alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  onError={e => { (e.target as HTMLImageElement).src = `https://placehold.co/400x300/0a1f5c/4a9eff?text=${encodeURIComponent(item.title)}`; }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-2">
                  <p className="text-white text-xs font-semibold line-clamp-1">{item.title}</p>
                  {item.location && <p className="text-white/60 text-[10px] line-clamp-1">{item.location}</p>}
                </div>
                {item.has360 && (
                  <div className="absolute top-2 right-2"><Badge360 small /></div>
                )}
              </div>
            ))}
          </div>
          {/* mobile prev/next */}
          <div className="flex justify-center gap-4 mt-6">
            <button onClick={goPrev}
              className="w-11 h-11 rounded-full flex items-center justify-center"
              style={{ background:"rgba(10,30,80,0.80)", border:"1px solid rgba(100,170,255,0.30)" }}>
              <ChevronLeft className="w-5 h-5 text-white"/>
            </button>
            <button onClick={goNext}
              className="w-11 h-11 rounded-full flex items-center justify-center"
              style={{ background:"rgba(10,30,80,0.80)", border:"1px solid rgba(100,170,255,0.30)" }}>
              <ChevronRight className="w-5 h-5 text-white"/>
            </button>
          </div>
        </section>
      )}

      {/* ── IMMERSIVE 3-D SCENE (≥ 640 px) ──────────────────────── */}
      <section id="gallery-scene-section" className="relative select-none overflow-hidden"
        style={{
          background:"radial-gradient(ellipse 120% 90% at 50% 45%, rgba(7,26,74,0.55) 0%, rgba(4,17,46,0.55) 30%, rgba(2,8,14,0.60) 68%, rgba(1,6,16,0.65) 100%)",
          minHeight: sceneW < 640 ? 0 : SCENE_H+100,
          display: sceneW > 0 && sceneW < 640 ? "none" : undefined,
        }}>

        {/* layered background environment */}
        <StarField/>
        <CosmicGrid/>
        <NebulaBlobs/>
        <AuroraEffect/>
        <AmbientDust/>
        <VolumetricBloom/>

        {/* fullscreen button */}
        <button
          onClick={toggleFullscreen}
          title={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
          className="absolute top-4 right-4 z-30 w-10 h-10 rounded-full flex items-center justify-center transition-all group hover:scale-110"
          style={{ background:"rgba(10,30,80,0.70)", border:"1px solid rgba(100,170,255,0.30)", backdropFilter:"blur(12px)", boxShadow:"0 0 20px rgba(37,99,235,0.25)" }}>
          {isFullscreen
            ? <Minimize2 className="w-4 h-4 text-white/70 group-hover:text-white transition-colors"/>
            : <Maximize2 className="w-4 h-4 text-white/70 group-hover:text-white transition-colors"/>
          }
        </button>

        {/* nav arrows */}
        <button
          onClick={isRTL ? goNext : goPrev}
          className="absolute left-6 top-1/2 -translate-y-1/2 z-30 w-12 h-12 rounded-full flex items-center justify-center transition-all group hover:scale-110"
          style={{ background:"rgba(10,30,80,0.60)", border:"1px solid rgba(100,170,255,0.22)", backdropFilter:"blur(12px)", boxShadow:"0 0 20px rgba(37,99,235,0.18)" }}>
          {isRTL
            ? <ChevronRight className="w-5 h-5 text-white/65 group-hover:text-white transition-colors"/>
            : <ChevronLeft  className="w-5 h-5 text-white/65 group-hover:text-white transition-colors"/>
          }
        </button>
        <button
          onClick={isRTL ? goPrev : goNext}
          className="absolute right-6 top-1/2 -translate-y-1/2 z-30 w-12 h-12 rounded-full flex items-center justify-center transition-all group hover:scale-110"
          style={{ background:"rgba(10,30,80,0.60)", border:"1px solid rgba(100,170,255,0.22)", backdropFilter:"blur(12px)", boxShadow:"0 0 20px rgba(37,99,235,0.18)" }}>
          {isRTL
            ? <ChevronLeft  className="w-5 h-5 text-white/65 group-hover:text-white transition-colors"/>
            : <ChevronRight className="w-5 h-5 text-white/65 group-hover:text-white transition-colors"/>
          }
        </button>

        {/* 3-D perspective container */}
        <div ref={sceneRef} className="relative w-full"
          style={{
            height:SCENE_H, perspective:`${PERSP}px`,
            perspectiveOrigin:"50% 47%",
            cursor: isDragging.current ? "grabbing" : "grab",
          }}
          onMouseMove={onMouseMove} onMouseDown={onMouseDown}
          onMouseUp={onMouseUp} onMouseLeave={onMouseLeave}
          onWheel={onWheel}
        >
          {/* SVG orbital rings + connecting lines (behind cards) */}
          <OrbitalSVG sceneW={sceneW} slotAssignments={slotAssignments}/>

          {/* ground rings — perspective floor */}
          <GroundRing/>

          {/* rotatable scene (mouse spring + idle drift + Z dolly) */}
          <motion.div className="absolute inset-0"
            style={{ rotateX:sRotX, rotateY:sRotY, z:sSceneZ, transformStyle:"preserve-3d", willChange:"transform" }}>
            {slotAssignments.map(({ slot, item, slotIdx }) => (
              <GlassCard
                key={item.id}
                item={item} slot={slot} sceneW={sceneW}
                isCenter={slotIdx === 0}
                isFlying={flyingFrom === slotIdx}
                onClick={() => handleCardClick(slotIdx)}
              />
            ))}
          </motion.div>
        </div>

        {/* dot progress indicators */}
        <div className="absolute bottom-14 left-1/2 -translate-x-1/2 flex gap-2 z-20">
          {filtered.slice(0, Math.min(filtered.length, 12)).map((_, i) => (
            <button key={i}
              onClick={() => { setFlyingFrom(0); setCenterIdx(i); setTimeout(()=>setFlyingFrom(null),950); }}
              className="transition-all duration-400 rounded-full"
              style={{
                width: i === centerIdx ? 22 : 6, height:6,
                background: i === centerIdx
                  ? "linear-gradient(90deg,#3b82f6,#60a5fa)"
                  : "rgba(120,190,255,0.25)",
                boxShadow: i === centerIdx ? "0 0 10px rgba(59,130,246,0.6)" : "none",
              }}
            />
          ))}
        </div>

        {/* controls hint bar */}
        <motion.div
          className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-5 px-5 py-2.5 rounded-full text-xs whitespace-nowrap z-[21]"
          style={{
            background:"rgba(4,13,33,0.70)",
            border:"1px solid rgba(100,160,255,0.12)",
            backdropFilter:"blur(16px)",
            color:"rgba(255,255,255,0.50)",
          }}
          initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} transition={{ delay:1.2 }}>
          <span className="flex items-center gap-1.5">
            <Move className="w-3.5 h-3.5" style={{ color:"#60a5fa" }}/> {t("gallery.dragToRotate")}
          </span>
          <span className="w-px h-3" style={{ background:"rgba(100,160,255,0.18)" }}/>
          <span className="flex items-center gap-1.5">
            <MousePointer className="w-3.5 h-3.5" style={{ color:"#60a5fa" }}/> {t("gallery.scrollToMove")}
          </span>
          <span className="w-px h-3" style={{ background:"rgba(100,160,255,0.18)" }}/>
          <span className="flex items-center gap-1.5">
            <MousePointer2 className="w-3.5 h-3.5" style={{ color:"#60a5fa" }}/> {t("gallery.clickToOpen")}
          </span>
        </motion.div>

        <FogVignette/>
      </section>

      {/* ── THUMBNAIL SELECTOR STRIP ──────────────────────────────── */}
      <section style={{ background:"rgba(4,13,33,0.98)", borderTop:"1px solid rgba(37,99,235,0.12)", borderBottom:"1px solid rgba(37,99,235,0.12)", padding:"16px 0" }}>
        <div className="container mx-auto px-6">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-xs font-semibold tracking-widest uppercase" style={{ color:"rgba(120,195,255,0.55)" }}>
              {t("gallery.selectFeatured")}
            </span>
            <div style={{ flex:1, height:1, background:"linear-gradient(90deg, rgba(37,99,235,0.25), transparent)" }}/>
            <span className="text-xs" style={{ color:"rgba(120,195,255,0.35)" }}>
              {centerIdx + 1} / {filtered.length}
            </span>
          </div>
          <div
            className="flex gap-3 overflow-x-auto pb-1"
            style={{ scrollbarWidth:"thin", scrollbarColor:"rgba(37,99,235,0.35) transparent" }}
          >
            {filtered.map((item, i) => {
              const isActive = i === centerIdx;
              return (
                <motion.button
                  key={item.id}
                  onClick={() => {
                    setFlyingFrom(centerIdx);
                    setCenterIdx(i);
                    setTimeout(() => setFlyingFrom(null), 950);
                  }}
                  className="relative shrink-0 overflow-hidden"
                  style={{
                    width: 72, height: 54,
                    borderRadius: 10,
                    border: isActive
                      ? "2px solid rgba(96,165,250,0.90)"
                      : "2px solid rgba(80,140,255,0.18)",
                    boxShadow: isActive
                      ? "0 0 18px rgba(37,99,235,0.65), 0 0 6px rgba(96,165,250,0.5)"
                      : "none",
                    transition: "border-color 0.25s, box-shadow 0.25s",
                    cursor: "pointer",
                    background: "rgba(10,30,80,0.5)",
                    outline: "none",
                    padding: 0,
                  }}
                  whileHover={{ scale: 1.08, zIndex: 2 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <img
                    src={item.url}
                    alt={item.title}
                    style={{
                      width: "100%", height: "100%",
                      objectFit: "cover",
                      filter: isActive
                        ? "brightness(1) saturate(1.2)"
                        : "brightness(0.60) saturate(0.8)",
                      transition: "filter 0.3s ease",
                    }}
                    onError={e => {
                      (e.target as HTMLImageElement).src =
                        `https://placehold.co/72x54/0a1f5c/4a9eff?text=${encodeURIComponent(item.title.slice(0,6))}`;
                    }}
                  />
                  {/* active glow overlay */}
                  {isActive && (
                    <motion.div
                      initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                      style={{
                        position: "absolute", inset: 0,
                        background: "linear-gradient(135deg, rgba(59,130,246,0.22) 0%, transparent 60%)",
                        borderRadius: 8,
                        pointerEvents: "none",
                      }}
                    />
                  )}
                  {/* active indicator dot */}
                  {isActive && (
                    <motion.div
                      initial={{ scale: 0 }} animate={{ scale: 1 }}
                      style={{
                        position: "absolute", bottom: 4, right: 4,
                        width: 7, height: 7, borderRadius: "50%",
                        background: "linear-gradient(135deg,#60a5fa,#3b82f6)",
                        boxShadow: "0 0 8px rgba(96,165,250,0.9)",
                      }}
                    />
                  )}
                  {/* featured star label */}
                  {isActive && (
                    <div style={{
                      position: "absolute", top: 3, left: 3,
                      fontSize: 8, fontWeight: 700,
                      color: "#dbeafe", letterSpacing: "0.06em",
                      background: "rgba(29,78,216,0.80)",
                      borderRadius: 6, padding: "1px 5px",
                      backdropFilter: "blur(6px)",
                      border: "1px solid rgba(120,195,255,0.35)",
                    }}>
                      ★
                    </div>
                  )}
                </motion.button>
              );
            })}
          </div>
        </div>
      </section>

      <FullscreenModal item={selected} onClose={closeItem} onPrev={prevItem} onNext={nextItem}/>

      {/* ── 360° PANORAMA OVERLAY (lazy-loaded, virtual tour) ───────── */}
      <Suspense fallback={null}>
        {panoramaItem && (
          <PanoramaOverlay
            panoramaUrl={panoramaItem.panoramaUrl!}
            title={panoramaItem.title}
            location={panoramaItem.location}
            hotspots={panoramaItem.hotspots}
            onNavigate={(targetId) => {
              const next = galleryItems.find(it => it.id === targetId && it.panoramaUrl);
              if (next) setPanoramaItem(next);
            }}
            onClose={() => setPanoramaItem(null)}
          />
        )}
      </Suspense>

      <Footer/>
      </div>{/* end z-index:10 content wrapper */}
    </div>
  );
}
