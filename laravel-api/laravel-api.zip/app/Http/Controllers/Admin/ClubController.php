<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Club;
use App\Models\MediaAsset;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ClubController extends Controller
{
    // ------------------------------------------------------------------ //
    // Helpers
    // ------------------------------------------------------------------ //

    private function mapOutput(Club $c): array
    {
        return [
            'id'              => $c->id,
            'name'            => $c->name,
            'slug'            => $c->slug,
            'description'     => $c->description,
            'longDescription' => $c->long_description,
            'image'           => $c->image,
            'heroImage'       => $c->hero_image,
            'location'        => $c->location,
            'contactPhone'    => $c->contact_phone,
            'contactEmail'    => $c->contact_email,
            'website'         => $c->website,
            'established'     => $c->established,
            'isActive'        => (bool) $c->is_active,
            'isFeatured'      => (bool) ($c->is_featured ?? false),
            'latitude'        => $c->latitude,
            'longitude'       => $c->longitude,
            'socialMedia'     => $c->social_media ?? [],
            'features'        => $c->features ?? [],
            'rating'          => $c->rating,
            'memberCount'     => $c->member_count ?? 0,
            'createdAt'       => $c->created_at?->toISOString(),
            'updatedAt'       => $c->updated_at?->toISOString(),
        ];
    }

    private function mapInput(Request $r): array
    {
        return array_filter([
            'name'             => $r->input('name'),
            'slug'             => $r->input('slug'),
            'description'      => $r->input('description'),
            'long_description' => $r->input('longDescription'),
            'image'            => $r->input('image'),
            'hero_image'       => $r->input('heroImage') ?? $r->input('hero_image'),
            'location'         => $r->input('location'),
            'contact_phone'    => $r->input('contactPhone'),
            'contact_email'    => $r->input('contactEmail'),
            'website'          => $r->input('website'),
            'established'      => $r->input('established'),
            'is_active'        => $r->has('isActive') ? (bool) $r->input('isActive') : null,
            'latitude'         => $r->input('latitude'),
            'longitude'        => $r->input('longitude'),
            'social_media'     => $r->input('socialMedia', []),
            'features'         => $r->input('features', []),
        ], fn($v) => $v !== null);
    }

    // ------------------------------------------------------------------ //
    // CRUD
    // ------------------------------------------------------------------ //

    /** Lightweight list for dropdowns: returns id + name of all clubs. */
    public function simpleList()
    {
        $clubs = Club::select('id', 'name')->orderBy('name')->get();
        return response()->json($clubs);
    }

    public function index(Request $request)
    {
        $query = Club::query();

        // Club managers only see their own club
        $authUser = auth()->user();
        if ($authUser && $authUser->role === 'club_manager') {
            $query->where('owner_id', $authUser->id);
        }

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(fn($q) => $q->where('name', 'like', "%$s%")
                ->orWhere('location', 'like', "%$s%"));
        }

        if ($request->filled('status') && $request->status !== 'all') {
            match ($request->status) {
                'active'   => $query->where('is_active', true),
                'inactive' => $query->where('is_active', false),
                'pending'  => $query->whereNull('is_active'),
                default    => null,
            };
        }

        $page    = max(1, (int) ($request->page    ?? 1));
        $perPage = max(1, min(100, (int) ($request->perPage ?? $request->limit ?? 25)));
        $total   = $query->count();

        $clubs = $query->orderBy('created_at', 'desc')
                       ->skip(($page - 1) * $perPage)
                       ->take($perPage)
                       ->get()
                       ->map(fn($c) => $this->mapOutput($c));

        return response()->json([
            'clubs'      => $clubs,
            'total'      => $total,
            'page'       => $page,
            'perPage'    => $perPage,
            'totalPages' => (int) ceil($total / $perPage),
        ]);
    }

    public function show($id)
    {
        return response()->json($this->mapOutput(Club::findOrFail($id)));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'         => 'required|string|max:255',
            'contactEmail' => 'nullable|email|max:255',
            'website'      => 'nullable|url|max:255',
            'latitude'     => 'nullable|numeric',
            'longitude'    => 'nullable|numeric',
        ]);

        $data                = $this->mapInput($request);
        $data['slug']        = $data['slug'] ?? Str::slug($request->input('name'));
        $data['is_active']   = $data['is_active'] ?? true;
        $data['description'] = $data['description'] ?? '';

        $club = Club::create($data);

        return response()->json($this->mapOutput($club->fresh()), 201);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'contactEmail' => 'nullable|email|max:255',
            'website'      => 'nullable|url|max:255',
            'latitude'     => 'nullable|numeric',
            'longitude'    => 'nullable|numeric',
        ]);

        $club = Club::findOrFail($id);
        $data = $this->mapInput($request);

        if (isset($data['name']) && !isset($data['slug'])) {
            $data['slug'] = Str::slug($data['name']);
        }

        $club->update($data);

        return response()->json($this->mapOutput($club->fresh()));
    }

    public function destroy($id)
    {
        Club::findOrFail($id)->delete();
        return response()->json(['message' => 'Club deleted']);
    }

    public function approve($id)
    {
        $club = Club::findOrFail($id);
        $club->update(['is_active' => true]);
        return response()->json($this->mapOutput($club->fresh()));
    }

    public function reject($id)
    {
        $club = Club::findOrFail($id);
        $club->update(['is_active' => false]);
        return response()->json($this->mapOutput($club->fresh()));
    }

    public function feature($id)
    {
        $club = Club::findOrFail($id);
        $club->update(['is_featured' => !($club->is_featured ?? false)]);
        return response()->json($this->mapOutput($club->fresh()));
    }

    public function uploadImage(Request $request)
    {
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,webp|max:5120',
        ]);

        $file     = $request->file('image');
        $origName = $file->getClientOriginalName();
        $ext      = $file->getClientOriginalExtension() ?: 'jpg';
        $uuid     = (string) Str::uuid();
        $filename = $uuid . '.' . $ext;
        $mime     = $file->getMimeType() ?? 'image/jpeg';

        Storage::disk('public')->put('media/' . $filename, file_get_contents($file->getRealPath()));
        $fileUrl = '/storage/media/' . $filename;

        $asset = MediaAsset::create([
            'file_name'     => $origName,
            'file_type'     => $mime,
            'file_size'     => $file->getSize(),
            'file_url'      => $fileUrl,
            'thumbnail_url' => $fileUrl,
            'alt_text'      => $request->input('alt', pathinfo($origName, PATHINFO_FILENAME)),
            'uploaded_by'   => $request->user()?->id ?? 'system',
        ]);

        return response()->json([
            'url'     => $fileUrl,
            'fileUrl' => $fileUrl,
            'id'      => $asset->id,
        ]);
    }
}
