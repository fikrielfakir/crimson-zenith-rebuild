<?php

namespace App\Mail;

use App\Models\BookingTicket;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class BookingConfirmed extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public BookingTicket $ticket) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Booking Confirmed — ' . ($this->ticket->event?->title ?? 'Your Event') . ' [' . $this->ticket->booking_reference . ']',
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.booking-confirmed',
        );
    }
}
